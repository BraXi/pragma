LibreQuake lq-dev textures ported to pragma

Your level editor should be configured to ONLY show TGA textures

extract textures to your basepr folder

WAL files are blank textures for ericw-tools that are only used 
during map compilation process and store essential info for bsp tools

https://github.com/MissLavender-LQ/LibreQuake/