pragma gamepack for netradiant

https://github.com/BraXi/pragma